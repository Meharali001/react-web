import React from 'react'
import './Banner.css'
import Bannertxt from './Bannertxt'





const Banner = () => {
  return (
    <>
    <div className="banner">
    <div className="container">
    <Bannertxt/>
     
        
    </div>
    </div>
    </>
  )
}

export default Banner

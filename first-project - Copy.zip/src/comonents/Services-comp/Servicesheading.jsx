import React from 'react'
import './Servicesheading.css'
import Smallbtn from '../Button-Comp/Smallbtn'



const Servicesheading = () => {
  return (
   
    
    <div className='Servicesheading'>
      <Smallbtn name="our Services"/>
     <h2 className='heading-txt'>The Care You Need, Exactly Where You Want It</h2>
    </div>
    
  
  )
}

export default Servicesheading

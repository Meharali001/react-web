import React from 'react'
import Servicessec from '../Services-comp/Servicessec'

const Services = () => {
  return (
    <div>
      <Servicessec/>
    </div>
  )
}

export default Services

import React from 'react'
import Aboutsec from '../About-comp/Aboutsec'




const About = () => {
  return (
  <div>
    <Aboutsec/>
  </div>
  )
}

export default About

import React from 'react'
import Contactsec from '../Contact-comp/Contactsec'

const Contect = () => {
  return (
   <>
  <Contactsec/>
   </>
  )
}

export default Contect

import React from 'react'
import './Contactcol2.css'

const Contactcol2 = () => {
  return (
    <>
    <img src="https://tuskerscaresolutions.com/wp-content/uploads/2024/05/contact.png" alt="" />
    </>
  )
}

export default Contactcol2

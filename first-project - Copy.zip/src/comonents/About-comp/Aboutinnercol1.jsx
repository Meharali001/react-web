import React from 'react'
import './Aboutinnercol1.css'

const Aboutinnercol1 = () => {
  return (
    <div className="aboutinner-col1">
        <img src="https://tuskerscaresolutions.com/wp-content/uploads/2024/05/about.png" alt="" />
    </div>
  )
}

export default Aboutinnercol1

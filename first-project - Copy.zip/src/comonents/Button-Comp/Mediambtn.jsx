import React from 'react'
import './Button.css'

const Mediambtn = (props) => {
  return (
    <div>
      <a href="" className='mediam-btn'>{props.name}</a>
    </div>
  )
}

export default Mediambtn
